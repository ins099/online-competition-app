export const SIGN_IN = 'SIGN_IN';
export const SIGN_IN_SUCCESS = 'SIGN_IN_SUCCESS';
export const SIGN_IN_FAILURE = 'SIGN_IN_FAILURE';

export const SIGN_UP = 'SIGN_UP';
export const SIGN_UP_SUCCESS = 'SIGN_UP_SUCCESS';
export const SIGN_UP_FAILURE = 'SIGN_UP_FAILURE';

export const SIGN_OUT = 'SIGN_OUT';
export const SIGN_OUT_SUCCESS = 'SIGN_OUT_SUCCESS';
export const SIGN_OUT_FAILURE = 'SIGN_OUT_FAILURE';



export const FETCH_TASK = 'FETCH_TASK';
export const FETCH_TASK_SUCCESS = 'FETCH_TASK_SUCCESS';
export const FETCH_TASK_FAILURE = 'FETCH_TASK_FAILURE';

export const EMPTY_TASK = 'EMPTY_TASK';
export const EMPTY_TASK_SUCCESS = 'EMPTY_TASK_SUCCESS';
export const EMPTY_TASK_FAILURE = 'EMPTY_TASK_FAILURE';




export const SUBMIT_ENTRY = 'SUBMIT_ENTRY';
export const SUBMIT_ENTRY_SUCCESS = 'SUBMIT_ENTRY_SUCCESS';
export const SUBMIT_ENTRY_FAILURE = 'SUBMIT_ENTRY_FAILURE';