export const BASE_URL = 'https://enigmatic-brushlands-96394.herokuapp.com';
export const API_VERSION = '';

export const API_ENDPOINTS = {
  signup: 'user/register',
  signin: 'user/login',
  task:'competitions',
  video_premium:'video/premium',
  contact:'contact',
  payment:'payment'
}